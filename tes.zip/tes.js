/// <reference types="cypress" />


describe('tes automation', () => {

    beforeEach(() => {
        cy.viewport(1920, 1080)

    })
    it('saat nya tes', () => {
        cy.visit('https://dev-nba.dutfin.net/')
        cy.contains('Lewati').click()
        cy.contains('Selamat Datang').should('be.visible')
        cy.get("#employee_code").type('automation')
        cy.get("#password").type('Nriin2021!')
        cy.contains('Masuk').click()
        cy.get("[class='clock-attendance__icon']").click()
        cy.contains('Kartu Absen').should('be.visible')
        cy.get("#approver_id").select('Bambang Pamungkas')
        cy.get("#is_remote").should('be.checked')
        cy.get("#remarksOptional").type('aku cinta NRI')
        cy.contains('Mulai').click()
        cy.url().should('include', '/homepage')
        cy.contains('Dalam Proses').should('be.visible')
        cy.get("[class='navigation-item navigation-item--with-line active']").click()
        cy.get("[class='button__content']").click()
        cy.contains('Filter Data Absensi').should('be.visible')
        
})
})